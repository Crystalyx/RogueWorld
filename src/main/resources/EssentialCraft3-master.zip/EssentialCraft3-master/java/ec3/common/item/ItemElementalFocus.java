package ec3.common.item;

import net.minecraft.item.Item;

public class ItemElementalFocus extends Item{

}
