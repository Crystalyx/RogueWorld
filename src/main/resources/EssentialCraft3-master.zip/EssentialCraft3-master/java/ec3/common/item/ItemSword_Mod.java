package ec3.common.item;

import net.minecraft.item.ItemSword;

public class ItemSword_Mod extends ItemSword{

	public ItemSword_Mod(ToolMaterial p_i45347_1_) {
		super(p_i45347_1_);
	}

}
