package ec3.common.block;

import net.minecraft.block.BlockBush;

public class BlockModFlower extends BlockBush{

	public BlockModFlower() {
		super();
		this.setStepSound(soundTypeGrass);
		// TODO Auto-generated constructor stub
	}

}
