package ec3.client.gui;

import DummyCore.Client.GuiCommon;
import net.minecraft.inventory.Container;
import net.minecraft.tileentity.TileEntity;

public class GuiMINEjector extends GuiCommon{

	public GuiMINEjector(Container c, TileEntity tile) {
		super(c,tile);
	}
	
	

}
