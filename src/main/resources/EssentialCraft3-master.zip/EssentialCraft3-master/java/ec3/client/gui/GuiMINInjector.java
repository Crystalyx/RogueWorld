package ec3.client.gui;

import DummyCore.Client.GuiCommon;
import net.minecraft.inventory.Container;
import net.minecraft.tileentity.TileEntity;

public class GuiMINInjector extends GuiCommon{

	public GuiMINInjector(Container c, TileEntity tile) {
		super(c,tile);
	}
	
	

}
