package ec3.api;

public enum EnumSpellType {
	
	CONSUMING,
	MIRACLE,
	SORCERY;

}
