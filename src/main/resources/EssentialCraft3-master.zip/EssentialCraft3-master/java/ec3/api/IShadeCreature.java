package ec3.api;

import net.minecraft.entity.Entity;

public interface IShadeCreature {
	
	public abstract float shadeBurstValue(Entity e);

}
