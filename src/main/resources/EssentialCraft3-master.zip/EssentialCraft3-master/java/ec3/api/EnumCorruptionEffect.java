package ec3.api;

public enum EnumCorruptionEffect {
	
	BODY,
	MIND,
	MATRIX;

}
