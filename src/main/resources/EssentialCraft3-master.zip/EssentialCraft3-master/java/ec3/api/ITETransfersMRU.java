package ec3.api;

/**
 * 
 * @author Modbder
 * @Description this is used to create devices that will transfer MRU
 */
public interface ITETransfersMRU extends ITEHasMRU {

}
