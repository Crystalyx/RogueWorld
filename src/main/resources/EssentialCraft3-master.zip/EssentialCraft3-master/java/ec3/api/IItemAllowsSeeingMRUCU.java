package ec3.api;

public interface IItemAllowsSeeingMRUCU {

}
