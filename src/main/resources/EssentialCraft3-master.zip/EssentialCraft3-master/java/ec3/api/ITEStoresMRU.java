package ec3.api;

/**
 * 
 * @author Modbder
 * @Description this is used if you want to create some kind of storage device
 */
public interface ITEStoresMRU extends ITEHasMRU {

}
