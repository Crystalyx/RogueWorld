# EssentialCraft3
EssentialCraft3 is a huge magic themed industrial mod, which adds a lot of content to the game. New energy, recipes, tools, armor, devices, bosses - event new dimension exists!

Feel free to report bugs/lags. However, please, attach a crashreport when reporting bugs!

If you want to make an addod - grab your DEV version:

4.5.1710.201 - http://www.mediafire.com/download/4chird8z7923d4q/EssentialCraftv4.5.1710.201DEV.jar
4.5.1710.204 - http://www.mediafire.com/download/d182989q875c76r/EssentialCraftv4.5.1710.204DEV.jar
