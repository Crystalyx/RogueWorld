package ec3.common.registry;

import net.minecraft.enchantment.Enchantment;

public class EnchantRegistry {
	
	public static void register()
	{
	}
	
	
	
	public static Enchantment ec23;
	public static Enchantment magnetism;
	public static Enchantment repare;
	public static Enchantment overseeing;

}
