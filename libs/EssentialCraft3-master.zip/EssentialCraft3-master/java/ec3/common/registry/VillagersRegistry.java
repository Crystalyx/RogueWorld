package ec3.common.registry;

public class VillagersRegistry {
	public static VillagersRegistry instance;
	
	public void register()
	{
	}

}
