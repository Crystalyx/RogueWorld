package ec3.common.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class ModBlock extends Block{

	public ModBlock(Material p_i45394_1_) {
		super(p_i45394_1_);
		// TODO Auto-generated constructor stub
	}

}
