package ec3.common.item;

import net.minecraft.item.Item;

public class ItemUpgrade extends Item{

}
