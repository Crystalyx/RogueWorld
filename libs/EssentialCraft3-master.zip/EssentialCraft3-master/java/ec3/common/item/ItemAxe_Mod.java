package ec3.common.item;

import net.minecraft.item.ItemAxe;

public class ItemAxe_Mod extends ItemAxe{

	public ItemAxe_Mod(ToolMaterial p_i45347_1_) {
		super(p_i45347_1_);
	}

}
