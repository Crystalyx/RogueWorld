package ec3.common.item;

import net.minecraft.item.ItemSpade;

public class ItemShovel_Mod extends ItemSpade{

	public ItemShovel_Mod(ToolMaterial p_i45347_1_) {
		super(p_i45347_1_);
	}

}
