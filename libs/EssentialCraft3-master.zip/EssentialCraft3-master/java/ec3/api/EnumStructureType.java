package ec3.api;

public enum EnumStructureType {
	
	MRUCUContaigementChamber,
	MRUCoil;

}
