package ec3.api;

/**
 * 
 * @author Modbder
 * @Description this is used to create devices that need MRU to work
 */
public interface ITERequiresMRU extends ITEHasMRU {

}
