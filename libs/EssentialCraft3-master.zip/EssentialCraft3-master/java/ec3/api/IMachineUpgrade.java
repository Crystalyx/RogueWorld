package ec3.api;

public interface IMachineUpgrade {
	
	public static enum UpgradeTypes
	{
		EFFICENCY,
		SPEED,
		TICK
	}

}
