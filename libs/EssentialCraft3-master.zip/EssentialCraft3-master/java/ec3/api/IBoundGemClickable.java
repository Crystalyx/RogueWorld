package ec3.api;

/**
 * 
 * @author Modbder
 * @Description Implement this in your blocks in order for the Bound Gem to be able to remember their position and dimension, even if they have no tile entity.
 */
public interface IBoundGemClickable {

}
